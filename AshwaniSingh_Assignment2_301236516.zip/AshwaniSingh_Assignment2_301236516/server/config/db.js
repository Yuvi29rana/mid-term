module.exports = 
{
    //"URI": "mongodb://localhost/book_store"
    "URI": "mongodb+srv://thomas:Hq3DKYN2NaAqGyyV@mongodbserver.k15hk.azure.mongodb.net/book_store?retryWrites=true&w=majority",
    "Secret": 'SomeSecret'
}